<div>

<div class="text-white bg-gradient-to-r from-green-800 to-green-400 h-24">

</div>

        <div class="container mx-auto">
            <div class="grid grid-cols-1 justify-center">
                <div class="text-center mt-56">
                    <a href="{{route('consulta')}}">
                    <button class="bg-sky-600 px-6 text-white py-4 rounded-lg w-1/2">Prestamo Notebook</button>
                    </a>
                </div>
                <div class="text-center mt-10">
                    <a href="{{route('consulta-devolucion')}}">
                    <button class="bg-amber-600 px-6 text-white py-4 rounded-lg w-1/2 ">Devolución Notebook</button>
                </a>
                </div>

            </div>
        </div>





</div>
