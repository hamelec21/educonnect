<x-app-layout>
    @livewire('menu.sidebar')

    <div class="ml-auto mb-6 lg:w-[75%] xl:w-[80] 2xl:w-[85%] py-2">
        
    </div>

</x-app-layout>
