<?php

namespace App\Http\Livewire\ModuloEquipos;

use Livewire\Component;

class IndexEquipos extends Component
{
    public function render()
    {
        return view('livewire.modulo-equipos.index-equipos');
    }
}
