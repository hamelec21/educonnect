<?php
use Illuminate\Support\Facades\Route;
use App\Http\Livewire\Curso\Show;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('auth/login');
});

Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified'
])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
});

Route::get('/index', function () {
    return view('index');
})->name('index');


Route::middleware(['auth:sanctum', 'verified'])->group(function () {
    Route::get('/curso/show',Show::class)->name('show-curso');
    Route::get('/statu/show',\App\Http\Livewire\Statu\Show::class)->name('show-estado');
    Route::get('/alumno/show',\App\Http\Livewire\Alumno\Show::class)->name('show-alumno');

                    /**rutas de modulo prestamos equipos Equipos**/

    Route::get('/modulo-equipos/show-prestamos',\App\Http\Livewire\ModuloEquipos\ShowPrestamos::class)->name('show-prestamos');
    //rutas de modulo devoluciones de equipos
    Route::get('/modulo-equipos/show-devoluciones',\App\Http\Livewire\ModuloEquipos\ShowDevoluciones::class)->name('show-devoluciones');
    //ruta de modulo equipos index
    Route::get('/modulo-equipos/index-equipos',\App\Http\Livewire\ModuloEquipos\IndexEquipos::class)->name('index-equipos');
});




                            /** Rutas publicas **/
    Route::get('/frontend/index',\App\Http\Livewire\frontend\Index::class)->name('index');

    Route::get('/frontend/consulta',\App\Http\Livewire\frontend\Consulta::class)->name('consulta');

    //rutas para crea prestamos de los equipos

    Route::get('/frontend/crear-prestamo/{rut}',\App\Http\Livewire\frontend\CrearPrestamo::class)->name('crear-prestamo');

    //rutas para crea devoluciones de los equipos

    Route::get('/frontend/consulta-devolucion/',\App\Http\Livewire\frontend\ConsultaDevolucion::class)->name('consulta-devolucion');

    Route::get('/frontend/crear-devolucion/{rut}',\App\Http\Livewire\frontend\CrearDevolucion::class)->name('crear-devolucion');


        //Rutas para carros N° 1



